ENV2 Backend/API Team
Workers:
1. API Builder
2. Database Designer
3. Queue Engineer
4. Scraper Engineer
5. Auth/Secrets Checker
6. Service Runner
7. Error Handler
Output:
- docs/backend_plan.md
- memory/env2_memory.md
- reports/env2_status.md
