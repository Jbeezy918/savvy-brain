ENV1 Architecture Team
Workers:
1. System Architect
2. Repo Mapper
3. Data Flow Designer
4. Risk Analyst
5. Integration Planner
6. Memory Designer
7. Build Sequencer
Output:
- docs/build_blueprint.md
- memory/env1_memory.md
- reports/env1_status.md
