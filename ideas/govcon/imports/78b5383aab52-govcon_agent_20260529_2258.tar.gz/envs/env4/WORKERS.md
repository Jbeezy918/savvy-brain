ENV4 QA and Research Team
Workers:
1. QA Lead
2. Test Writer
3. Bug Hunter
4. Security Reviewer
5. Performance Analyst
6. Documentation Writer
7. Research Analyst
Output:
- reports/qa_findings.md
- memory/env4_memory.md
- reports/env4_status.md
