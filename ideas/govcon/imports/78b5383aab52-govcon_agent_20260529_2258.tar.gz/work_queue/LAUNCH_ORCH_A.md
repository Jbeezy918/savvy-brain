Read orchestrators/ORCH_A.md, envs/env1/WORKERS.md, envs/env2/WORKERS.md.
Create/update required docs, memory, and reports.
Do not summarize only. Write the files.
