# ROUND 1 LAUNCH PROMPT

You are assigned to the GovCon Agent training swarm.

Read:
1. AGENT_ROSTER.md
2. Your ROUND_1 lane file
3. ROUND_1_SCORE_INSTRUCTIONS.md

Your job:
- Complete Foundation 01 training.
- Identify your role.
- Produce your readiness report in agent_reports/.
- Self-score honestly.
- List blockers.
- Do not fake readiness.

Required output file:
agent_reports/YOUR_AGENT_NAME_ROUND_1.md
