# ENV2 Memory

## API Builder
- Responsible for designing and implementing the backend APIs.
- Tracks progress on API development milestones.

## Database Designer
- Designs and manages the database schema.
- Ensures data integrity and efficient querying.

## Queue Engineer
- Manages task queues to ensure smooth processing of requests.
- Monitors queue performance and optimizes as needed.

## Scraper Engineer
- Develops web scraping tools to gather necessary data.
- Ensures compliance with legal and ethical standards for data collection.

## Auth/Secrets Checker
- Implements authentication mechanisms and manages secrets securely.
- Conducts regular security audits to identify vulnerabilities.

## Service Runner
- Manages the deployment and scaling of backend services.
- Ensures high availability and reliability of services.

## Error Handler
- Develops robust error handling mechanisms.
- Logs errors for analysis and resolution.
