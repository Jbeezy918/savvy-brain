import json, re, time, threading, random, webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk
from duckduckgo_search import DDGS

ROOT = Path.home() / "Desktop" / "GovCon_Research_Harvester"
running = False

TOPICS = [
    "government contracting", "SAM.gov opportunities", "NAICS codes", "RFP analysis",
    "RFQ sourcing", "set aside contracts", "federal acquisition regulation",
    "proposal writing", "compliance matrix", "past performance", "price realism",
    "government logistics contracts", "munitions procurement", "defense contracting",
    "DLA contracting", "Army contracting", "overseas sales compliance",
    "ITAR compliance", "export controls", "supply chain contracting",
    "sales tactics", "car sales tactics", "B2B sales", "closing techniques",
    "negotiation psychology", "persuasion", "behavioral economics",
    "pricing strategy", "marketing psychology", "customer discovery",
    "cold outreach", "lead generation", "objection handling", "enterprise sales",
    "contract pricing", "capture management", "bid/no-bid strategy",
    "competitor research", "market research", "vendor registration",
    "capability statement", "teaming agreements", "subcontracting strategy",
    "government buyer psychology", "procurement cycles", "economic buying behavior"
]

def safe(s):
    return re.sub(r"[^a-zA-Z0-9_.-]", "_", s)[:100]

def folder_size_mb(path):
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1024 / 1024 if path.exists() else 0

def build_queries(base, broad):
    if broad:
        return [
            base,
            f"{base} tactics",
            f"{base} strategy",
            f"{base} case study",
            f"{base} recent trends",
        ]
    return [
        base,
        f"{base} government contracting",
        f"{base} federal procurement",
    ]

def harvest():
    global running
    if running:
        log("Already running. Chill, turbo.")
        return
    running = True

    ROOT.mkdir(parents=True, exist_ok=True)

    manual = query_var.get().strip()
    selected = topic_var.get().strip()
    broad = broad_var.get()

    base = manual or (random.choice(TOPICS) if selected == "RANDOM" else selected)
    queries = build_queries(base, broad)

    year = time.strftime("%Y")
    category = safe(base.lower().replace(" ", "_"))
    folder = ROOT / category / year
    folder.mkdir(parents=True, exist_ok=True)

    log(f"\nSTART: {base}")
    log(f"Mode: {'BROAD' if broad else 'NARROW'}")
    log(f"Saving to: {folder}")

    try:
        with DDGS() as ddgs:
            count = 0
            for q in queries:
                log(f"\nSearching: {q}")
                for result in ddgs.text(q, max_results=20):
                    count += 1
                    file = folder / f"{count:03d}_{safe(result.get('title','result'))}.json"
                    result["query"] = q
                    result["saved_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                    file.write_text(json.dumps(result, indent=2), encoding="utf-8")
                    log(f"Saved: {file.name}")
                update_size()
                time.sleep(2)
        log(f"\nDONE: {count} results saved.")
    except Exception as e:
        log(f"ERROR: {e}")
    finally:
        running = False
        update_size()

def start_thread():
    threading.Thread(target=harvest, daemon=True).start()

def open_folder():
    ROOT.mkdir(parents=True, exist_ok=True)
    webbrowser.open(str(ROOT))

def update_size():
    size_label.config(text=f"Folder size: {folder_size_mb(ROOT):.2f} MB")

def log(msg):
    logbox.insert(tk.END, msg + "\n")
    logbox.see(tk.END)
    update_size()

app = tk.Tk()
app.title("GovCon Research Harvester v2")
app.geometry("950x700")

ttk.Label(app, text="GovCon Research Harvester v2", font=("Arial", 18)).pack(pady=8)

frame = ttk.Frame(app)
frame.pack(fill="x", padx=12)

ttk.Label(frame, text="Manual Search:").grid(row=0, column=0, sticky="w")
query_var = tk.StringVar()
ttk.Entry(frame, textvariable=query_var, width=80).grid(row=0, column=1, padx=8, pady=5)

ttk.Label(frame, text="Preset Topic:").grid(row=1, column=0, sticky="w")
topic_var = tk.StringVar(value="RANDOM")
topic_box = ttk.Combobox(frame, textvariable=topic_var, values=["RANDOM"] + TOPICS, width=78)
topic_box.grid(row=1, column=1, padx=8, pady=5)

broad_var = tk.BooleanVar(value=False)
ttk.Checkbutton(frame, text="Broad search", variable=broad_var).grid(row=2, column=1, sticky="w")

btns = ttk.Frame(app)
btns.pack(pady=10)

ttk.Button(btns, text="START HARVEST", command=start_thread).grid(row=0, column=0, padx=8)
ttk.Button(btns, text="OPEN DESKTOP FOLDER", command=open_folder).grid(row=0, column=1, padx=8)

size_label = ttk.Label(app, text="Folder size: 0.00 MB")
size_label.pack()

logbox = tk.Text(app, width=115, height=32)
logbox.pack(padx=10, pady=10)

app.mainloop()
