import csv
from pathlib import Path

path = Path("training_scores/ROUND_1_SCORECARD.csv")

with path.open() as f:
    rows = list(csv.DictReader(f))

print("\nROUND 1 TRAINING SCOREBOARD\n")
print(f"{'AGENT':<18} {'ROLE':<14} {'TOTAL':<8} {'STATUS'}")
print("-" * 55)

for r in rows:
    total = r.get("total_score", "").strip()
    status = "NOT SCORED"
    if total.isdigit():
        n = int(total)
        if n >= 63:
            status = "ELITE"
        elif n >= 56:
            status = "PASS"
        else:
            status = "RETRAIN"
    print(f"{r['agent']:<18} {r['role']:<14} {total or '-':<8} {status}")
