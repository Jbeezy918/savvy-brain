import subprocess, time, json
from pathlib import Path

ROOT = Path.home() / "AI_SYSTEM/projects/govcon_agent"
TASKS = [
    ("technical", "qwen2.5-coder:32b", "TECHNICAL.md"),
    ("safety", "qwen3-coder:30b", "SAFETY_COMPLIANCE.md"),
    ("operations", "qwen2.5-coder:14b", "OPERATIONS.md"),
    ("research", "llama3.1:8b", "MEMORY_RESEARCH.md"),
]

PROMPT = """
Read {md}.
Create:
- reports/{role}_findings.md
- memory/{role}_memory.md
- docs/{role}_build_tasks.md

Do not stop until files exist.
Extract requirements, risks, missing pieces, and next build tasks.
No summaries without file output.
"""

def run(role, model, md):
    print(f"\n=== START {role.upper()} using {model} ===")
    prompt = PROMPT.format(role=role, md=md)
    cmd = [
        "aider",
        "--model", f"ollama/{model}",
        "--yes-always",
        "--message", prompt,
    ]
    subprocess.run(cmd, cwd=ROOT)

while True:
    for role, model, md in TASKS:
        run(role, model, md)
        time.sleep(5)
    print("\n=== ROUND COMPLETE. ROTATING AGAIN ===")
