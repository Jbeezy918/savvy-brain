import csv
from pathlib import Path

def show_csv(title, path):
    print(f"\n{title}")
    print("=" * len(title))
    p = Path(path)
    if not p.exists():
        print("Missing:", path)
        return
    rows = list(csv.DictReader(p.open()))
    if not rows:
        print("No rows yet.")
        return
    for r in rows:
        print(" | ".join(f"{k}: {v or '-'}" for k, v in r.items()))

show_csv("AGENT LIFETIME SCORES", "training_scores/agent_lifetime_scores.csv")
show_csv("CREW SCORES", "training_scores/crew_scores.csv")
show_csv("ROUND SCORES", "training_scores/round_scores.csv")
