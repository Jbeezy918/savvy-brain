from pathlib import Path

files = [
    "work_queue/live/ROUND_1_LAUNCH_PROMPT.md",
    "work_queue/live/AGENT_ROSTER.md",
    "work_queue/live/ROUND_1_SCORE_INSTRUCTIONS.md",
    "work_queue/live/ROUND_1_TECHNICAL.md",
    "work_queue/live/ROUND_1_OPERATIONS.md",
    "work_queue/live/ROUND_1_RESEARCH.md",
    "work_queue/live/ROUND_1_AUTOMATION.md",
]

for f in files:
    print("\n\n" + "="*80)
    print(f)
    print("="*80)
    print(Path(f).read_text())
