#!/bin/bash
cd ~/AI_SYSTEM/projects/govcon_agent || exit 1

mkdir -p training_feed/{technical,safety,operations,research} work_queue/live logs

LANES=("technical" "safety" "operations" "research")
ROUND=1

while true; do
  echo "===== TRAINING ROUND $ROUND =====" | tee -a logs/training_feed.log

  for lane in "${LANES[@]}"; do
    OUT="work_queue/live/${lane}_TRAINING_ROUND_${ROUND}.md"
    echo "# ${lane^^} TRAINING ROUND $ROUND" > "$OUT"
    find ~/AI_SYSTEM ~/Desktop/GovCon_Research_Harvester -type f \( -name "*.md" -o -name "*.json" \) 2>/dev/null | sort -R | head -5 >> "$OUT"
    echo "Created $OUT" | tee -a logs/training_feed.log
  done

  ROUND=$((ROUND+1))
  sleep 1800
done
