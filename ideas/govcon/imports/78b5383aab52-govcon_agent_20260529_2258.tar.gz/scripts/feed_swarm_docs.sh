#!/bin/bash
cd ~/AI_SYSTEM/projects/govcon_agent || exit 1

mkdir -p swarm_docs/{technical,safety,operations,research} work_queue/live

# Build source document list from AI_SYSTEM, excluding junk/cache
find ~/AI_SYSTEM -type f -name "*.md" \
  ! -path "*/node_modules/*" \
  ! -path "*/.git/*" \
  ! -path "*/memory/*" \
  ! -path "*/reports/*" \
  | sort > work_queue/all_docs.txt

make_pack () {
  lane="$1"
  keywords="$2"
  grep -Ei "$keywords" work_queue/all_docs.txt | head -10 > "work_queue/${lane}_docs.txt"

  i=1
  while read -r file; do
    [ -f "$file" ] || continue
    cp "$file" "swarm_docs/${lane}/${i}_$(basename "$file")"
    i=$((i+1))
  done < "work_queue/${lane}_docs.txt"
}

make_pack technical "api|backend|frontend|mcp|database|architecture|dashboard|code|agent|relay"
make_pack safety "security|compliance|audit|risk|approval|backup|auth|privacy|safe"
make_pack operations "n8n|workflow|queue|schedule|deadline|deploy|monitor|automation|sop"
make_pack research "rag|memory|sam|gov|contract|award|research|competitor|procurement"

for lane in technical safety operations research; do
  echo "=== $lane ==="
  ls "swarm_docs/$lane" | head -10
done

for round in 1 2; do
  for lane in technical safety operations research; do
    start=$(( (round-1)*5 + 1 ))
    end=$(( round*5 ))

    outfile="work_queue/live/${lane}_ROUND_${round}.md"
    echo "# ${lane^^} ROUND $round" > "$outfile"
    echo "Read these docs. Extract lessons, risks, tasks, and write outputs." >> "$outfile"
    echo "" >> "$outfile"

    ls "swarm_docs/$lane" | sed -n "${start},${end}p" | while read f; do
      echo "- swarm_docs/$lane/$f" >> "$outfile"
    done
  done

  echo "ROUND $round READY:"
  ls work_queue/live/*ROUND_${round}.md

  [ "$round" = "1" ] && sleep 120
done

echo "DONE. Feed agents the ROUND files from work_queue/live/"
