#!/bin/bash
cd ~/AI_SYSTEM/projects/govcon_agent || exit 1
mkdir -p agents memory reports work_queue docs

for role in chief builder auditor researcher; do
  touch memory/${role}_memory.md
  cat >> memory/${role}_memory.md <<EOF

---
DATE: $(date)
ROLE: $role
TASK: START SESSION
LESSONS:
RISKS:
NEXT:
EOF
done

cat > work_queue/ROUND_1.md <<'EOF'
# ROUND 1
Chief: create architecture plan.
Builder: create first working skeleton.
Auditor: find failures, missing tests, bad structure.
Researcher: find missing APIs/tools/risks.
Everyone writes to memory and reports.
EOF

echo "SWARM READY"
echo "Launch agents from: ~/AI_SYSTEM/projects/govcon_agent"
