# ROUND 1
Chief: create architecture plan.
Builder: create first working skeleton.
Auditor: find failures, missing tests, bad structure.
Researcher: find missing APIs/tools/risks.
Everyone writes to memory and reports.
