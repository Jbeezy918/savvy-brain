# Backend Plan

## Mission
Provide the API layer that connects dashboard, orchestrators, training queue, memory, reports, and local model routing.

## Backend Responsibilities
1. Receive user tasks.
2. Validate task payloads.
3. Store tasks in queue.
4. Assign tasks to agent groups.
5. Read/write memory files.
6. Read/write report files.
7. Track active training sessions.
8. Expose scorecard status.
9. Route model requests.
10. Log failures.

## Candidate API Routes
- GET /health
- GET /status
- GET /agents
- GET /agents/active
- GET /training/queue
- POST /training/queue
- GET /reports
- GET /reports/{name}
- GET /memory
- POST /scorecard/update

## Data Stores
- memory/*.md
- reports/*.md
- docs/*.md
- work_queue/*.md
- CONTROL_CENTER/*.md
- AGENT_SCORECARD.md

## Service Rules
All writes must stay inside project root.
All model names must be verified before use.
Every task must create or update an output file.
Every agent run must update score/status.
No silent success without file output.

## Error Handling
- Missing file: create placeholder then write content.
- Missing model: fallback to approved model.
- Timeout: retry once, then log failure.
- Wrong directory: stop immediately.
- Empty output: score zero.

## Next Build Tasks
- Create backend service entrypoint.
- Add file-safe read/write helpers.
- Add agent registry loader.
- Add scorecard updater.
- Add queue runner.
- Add API health check.
- Add report listing endpoint.
