# GOVCON Agent Build Blueprint

## Mission
Build a local-first AI operations system for GovCon research, training packet generation, dashboard visibility, memory, scoring, and agent orchestration.

## Core Modules
1. Dashboard UI
2. Backend API
3. Agent Orchestrator
4. Research Harvester
5. Memory Store
6. Training Queue
7. Scoring System
8. Report Generator
9. Model Router
10. Safe Terminal Runner

## Required Folders
- src/agents
- src/api
- src/dashboard
- src/models
- src/tools
- docs
- reports
- memory
- work_queue

## Data Flow
User task enters dashboard.
Dashboard sends task to backend API.
Backend creates work item.
Orchestrator assigns work item to agent role.
Agent reads role memory and task context.
Agent writes output to docs, reports, or memory.
Scoring system evaluates output.
Final result is logged and displayed.

## Build Priorities
1. Stabilize file structure.
2. Create backend API routes.
3. Connect dashboard to backend.
4. Add agent task queue.
5. Add model router.
6. Add scorecard updates.
7. Add report viewer.
8. Add safe execution rules.

## Risks
- Agents writing into wrong folders.
- Model names not matching Ollama inventory.
- Too many simultaneous sessions.
- Empty placeholder files.
- Terminal prompts pasted into zsh instead of Aider.
- No scoring loop.

## Next Build Tasks
- Implement project status endpoint.
- Implement training queue endpoint.
- Implement scorecard writer.
- Implement agent registry loader.
- Implement dashboard panels for active agents.
- Implement output file viewer.
- Implement retry/error logging.
