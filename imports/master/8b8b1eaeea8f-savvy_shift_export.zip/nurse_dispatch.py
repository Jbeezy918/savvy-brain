import sys
import sqlite3
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QMessageBox
)
from PyQt5.QtCore import Qt


class NurseDispatchApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NursePickup - Shift Dispatch")
        self.resize(900, 600)

        # Initialize Database
        self.init_db()

        # Setup UI
        self.init_ui()
        self.load_jobs()

    def init_db(self):
        self.conn = sqlite3.connect("nurse_dispatch.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_name TEXT NOT NULL,
                address TEXT NOT NULL,
                phone TEXT NOT NULL,
                shift_date TEXT NOT NULL,
                role_needed TEXT NOT NULL,
                status TEXT DEFAULT 'Open'
            )
        """)
        self.conn.commit()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # Header Title
        title_label = QLabel("NursePickup - Real-Time Shift Dispatch")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
        main_layout.addWidget(title_label)

        # Form Layout for Posting Jobs (Chloe's View)
        form_layout = QHBoxLayout()

        self.client_input = QLineEdit()
        self.client_input.setPlaceholderText("Client Name")

        self.address_input = QLineEdit()
        self.address_input.setPlaceholderText("Address")

        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("Phone Number")

        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText("Date (YYYY-MM-DD)")

        self.role_input = QLineEdit()
        self.role_input.setPlaceholderText("Role (CNA/LPN/RN)")

        form_layout.addWidget(self.client_input)
        form_layout.addWidget(self.address_input)
        form_layout.addWidget(self.phone_input)
        form_layout.addWidget(self.date_input)
        form_layout.addWidget(self.role_input)

        main_layout.addLayout(form_layout)

        # Post Job Button
        self.post_btn = QPushButton("Post Shift")
        self.post_btn.setStyleSheet("background-color: #27AE60; color: white; font-weight: bold; padding: 8px;")
        self.post_btn.clicked.connect(self.post_job)
        main_layout.addWidget(self.post_btn)

        # Table to View Shifts
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["ID", "Client Name", "Address", "Phone", "Date", "Role", "Status"])
        main_layout.addWidget(self.table)

        # Claim Shift Button (Nurse View)
        self.claim_btn = QPushButton("Claim Selected Shift")
        self.claim_btn.setStyleSheet("background-color: #2980B9; color: white; font-weight: bold; padding: 8px;")
        self.claim_btn.clicked.connect(self.claim_job)
        main_layout.addWidget(self.claim_btn)

    def post_job(self):
        client = self.client_input.text().strip()
        address = self.address_input.text().strip()
        phone = self.phone_input.text().strip()
        date = self.date_input.text().strip()
        role = self.role_input.text().strip()

        if not client or not address or not phone or not date or not role:
            QMessageBox.warning(self, "Error", "Please fill in all fields to post a shift.")
            return

        self.cursor.execute(
            "INSERT INTO jobs (client_name, address, phone, shift_date, role_needed, status) VALUES (?, ?, ?, ?, ?, 'Open')",
            (client, address, phone, date, role)
        )
        self.conn.commit()

        # Clear inputs
        self.client_input.clear()
        self.address_input.clear()
        self.phone_input.clear()
        self.date_input.clear()
        self.role_input.clear()

        self.load_jobs()
        QMessageBox.information(self, "Success", "Shift posted successfully!")

    def load_jobs(self):
        self.cursor.execute("SELECT * FROM jobs")
        rows = self.cursor.fetchall()

        self.table.setRowCount(len(rows))
        for row_idx, row_data in enumerate(rows):
            for col_idx, data in enumerate(row_data):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(str(data)))

    def claim_job(self):
        selected_row = self.table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Selection Error", "Please select a shift from the table to claim.")
            return

        job_id = self.table.item(selected_row, 0).text()
        status = self.table.item(selected_row, 6).text()

        if status == "Assigned":
            QMessageBox.warning(self, "Already Taken", "This shift has already been claimed.")
            return

        self.cursor.execute("UPDATE jobs SET status = 'Assigned' WHERE id = ?", (job_id,))
        self.conn.commit()
        self.load_jobs()
        QMessageBox.information(self, "Success", "Shift successfully claimed! Client details have been assigned.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = NurseDispatchApp()
    window.show()
    sys.exit(app.exec_())
