from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

DB_PATH = Path(__file__).resolve().parent.parent / "savvyshift.db"


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _table_columns(cursor: sqlite3.Cursor, table_name: str) -> set[str]:
    rows = cursor.execute(f"PRAGMA table_info({table_name})").fetchall()
    return {row[1] for row in rows}


def init_db() -> None:
    conn = _connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            location_type TEXT,
            pay_rate REAL,
            start_time TEXT,
            end_time TEXT,
            requirements TEXT,
            status TEXT DEFAULT 'Open',
            assigned_worker_id INTEGER,
            requested_by INTEGER
        )
        """
    )

    shift_columns = _table_columns(cursor, "shifts")
    for column_name, column_def in {
        "title": "TEXT",
        "description": "TEXT",
        "location_type": "TEXT",
        "pay_rate": "REAL",
        "start_time": "TEXT",
        "end_time": "TEXT",
        "requirements": "TEXT",
        "status": "TEXT DEFAULT 'Open'",
        "assigned_worker_id": "INTEGER",
        "requested_by": "INTEGER",
    }.items():
        if column_name not in shift_columns:
            cursor.execute(f"ALTER TABLE shifts ADD COLUMN {column_name} {column_def}")

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS workers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            phone TEXT,
            license_number TEXT,
            role TEXT
        )
        """
    )

    worker_columns = _table_columns(cursor, "workers")
    for column_name, column_def in {
        "name": "TEXT",
        "phone": "TEXT",
        "license_number": "TEXT",
        "role": "TEXT",
    }.items():
        if column_name not in worker_columns:
            cursor.execute(f"ALTER TABLE workers ADD COLUMN {column_name} {column_def}")

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            address TEXT,
            phone TEXT
        )
        """
    )

    conn.commit()
    conn.close()

    if not get_shifts():
        seed_demo_data()


def seed_demo_data() -> None:
    conn = _connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO shifts (title, description, location_type, pay_rate, start_time, end_time, requirements, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Open')
        """,
        (
            "Weekend ICU Coverage",
            "Short-term overnight support",
            "Skilled Nursing Facility",
            38.0,
            "2026-07-25 19:00",
            "2026-07-26 07:00",
            "RN Verified",
        ),
    )

    cursor.execute(
        """
        INSERT INTO workers (name, phone, license_number, role)
        VALUES (?, ?, ?, ?)
        """,
        ("Maya Brooks", "555-2222", "RN-2048", "RN"),
    )

    conn.commit()
    conn.close()


def create_shift(
    title: str,
    description: str,
    location_type: str,
    pay_rate: float,
    start_time: str,
    end_time: str,
    requirements: str,
) -> dict[str, Any]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO shifts (title, description, location_type, pay_rate, start_time, end_time, requirements, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Open')
        """,
        (title, description, location_type, pay_rate, start_time, end_time, requirements),
    )
    conn.commit()
    shift_id = cursor.lastrowid
    conn.close()
    return {"id": shift_id, "status": "Open"}


def request_shift(shift_id: int, worker_id: int) -> tuple[bool, str]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute("SELECT status FROM shifts WHERE id = ?", (shift_id,))
    current = cursor.fetchone()

    if not current:
        conn.close()
        return False, "Shift not found."

    if current["status"] != "Open":
        conn.close()
        return False, "This shift is already assigned."

    cursor.execute(
        "UPDATE shifts SET status = 'Assigned', assigned_worker_id = ?, requested_by = ? WHERE id = ?",
        (worker_id, worker_id, shift_id),
    )
    conn.commit()
    conn.close()
    return True, "Shift successfully requested."


def cancel_shift(shift_id: int, worker_id: int) -> tuple[bool, str]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute("SELECT assigned_worker_id, status FROM shifts WHERE id = ?", (shift_id,))
    current = cursor.fetchone()

    if not current:
        conn.close()
        return False, "Shift not found."

    if current["status"] != "Assigned" or current["assigned_worker_id"] != worker_id:
        conn.close()
        return False, "You are not assigned to this shift."

    cursor.execute(
        "UPDATE shifts SET status = 'Open', assigned_worker_id = NULL, requested_by = NULL WHERE id = ?",
        (shift_id,),
    )
    conn.commit()
    conn.close()
    return True, "Shift cancelled and returned to marketplace."


def register_worker(
    name: str,
    phone: str,
    license_number: str,
    role: str = "",
) -> dict[str, Any]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO workers (name, phone, license_number, role) VALUES (?, ?, ?, ?)",
        (name, phone, license_number, role),
    )
    conn.commit()
    worker_id = cursor.lastrowid
    conn.close()
    return {"id": worker_id, "name": name}


def get_shifts() -> list[dict[str, Any]]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, title, description, location_type, pay_rate, start_time, end_time, requirements, status, assigned_worker_id, requested_by
        FROM shifts
        ORDER BY start_time, id DESC
        """
    )
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_workers() -> list[dict[str, Any]]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, phone, license_number, role FROM workers ORDER BY name")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_customers() -> list[dict[str, Any]]:
    conn = _connect()
    cursor = conn.cursor()
    cursor.execute("SELECT id, client_name, address, phone FROM customers ORDER BY client_name")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return rows


init_db()
