from nicegui import ui

from backend.logic import (
    create_shift,
    get_customers,
    get_shifts,
    get_workers,
    init_db,
    request_shift,
    cancel_shift,
    register_worker,
)

init_db()


def get_db_connection():
    import sqlite3

    conn = sqlite3.connect("savvyshift.db")
    conn.row_factory = sqlite3.Row
    return conn


@ui.page("/")
def main_page():
    ui.add_head_html("<style>.q-card { border-radius: 12px; }</style>")

    with ui.header().classes("bg-blue-grey-9 text-white q-px-md items-center justify-between"):
        ui.label("SavvyShift | Secure Marketplace & Scheduling").classes("text-h6 font-weight-bold")
        with ui.row():
            ui.button("Marketplace Calendar", on_click=lambda: tabs.set_value("calendar")).props("flat text-color=white")
            ui.button("Worker Portal", on_click=lambda: tabs.set_value("worker")).props("flat text-color=white")
            ui.button("Admin Command Center", on_click=lambda: tabs.set_value("admin")).props("flat text-color=white")

    with ui.tab_panels(tabs := ui.tabs().classes("hidden"), value="calendar").classes("w-full p-4"):
        with ui.tab_panel("calendar"):
            ui.label("Available Marketplace Shifts").classes("text-h5 q-mb-md")
            grid_container = ui.column().classes("w-full q-gutter-md")

            def refresh_calendar():
                grid_container.clear()
                shifts = get_shifts()
                open_shifts = [shift for shift in shifts if shift.get("status") == "Open"]

                if not open_shifts:
                    with grid_container:
                        ui.label("No open shifts currently available on the marketplace.").classes("text-grey")
                    return

                with grid_container:
                    for shift in open_shifts:
                        with ui.card().classes("w-full p-4 shadow-2 bg-white"):
                            with ui.row().classes("justify-between items-center w-full"):
                                ui.label(shift["title"]).classes("text-h6 text-primary")
                                ui.badge(f"${shift['pay_rate']}/hr", color="green")
                            ui.separator().classes("my-2")
                            ui.label(f"Location Type: {shift['location_type']}")
                            ui.label(f"Duration: {shift['start_time']} to {shift['end_time']}")
                            ui.label(f"Requirements: {shift['requirements']}").classes("text-grey-7 text-sm")
                            with ui.row().classes("justify-end q-mt-sm"):
                                ui.button("Request Job", on_click=lambda sid=shift["id"]: handle_request(sid, 1)).props("color=primary unelevated")

            def handle_request(sid, wid):
                success, msg = request_shift(sid, wid)
                if success:
                    ui.notify("Shift successfully requested!", type="positive")
                    refresh_calendar()
                else:
                    ui.notify(msg, type="negative")

            refresh_calendar()
            ui.button("Refresh Marketplace", on_click=refresh_calendar).props("outline icon=refresh").classes("q-mt-md")

        with ui.tab_panel("worker"):
            ui.label("Worker Dashboard & Active Commitments").classes("text-h5 q-mb-md")
            my_shifts_container = ui.column().classes("w-full q-gutter-md")

            def refresh_worker_dashboard():
                my_shifts_container.clear()
                assigned = [shift for shift in get_shifts() if shift.get("assigned_worker_id") == 1]

                with my_shifts_container:
                    ui.label("Your Assigned Shifts").classes("text-subtitle1 font-bold")
                    if not assigned:
                        ui.label("You have no active shift commitments.").classes("text-grey")
                    for shift in assigned:
                        with ui.card().classes("w-full p-4 bg-blue-5"):
                            ui.label(shift["title"]).classes("text-h6")
                            ui.label(f"Time: {shift['start_time']} - {shift['end_time']}")

                            def open_cancel_dialog(shift_id):
                                with ui.dialog() as dialog, ui.card().classes("p-6"):
                                    ui.label("Confirm Cancellation").classes("text-h6 text-negative")
                                    ui.label("Are you sure you want to cancel this shift? Repeated cancellations may affect your job request priority.")
                                    with ui.row().classes("justify-end q-mt-md"):
                                        ui.button("Back", on_click=dialog.close).props("flat")
                                        ui.button("Confirm Cancellation", on_click=lambda: execute_cancellation(shift_id, dialog)).props("color=negative")
                                dialog.open()

                            def execute_cancellation(shift_id, dialog):
                                success, msg = cancel_shift(shift_id, 1)
                                dialog.close()
                                if success:
                                    ui.notify("Shift cancelled and returned to marketplace.", type="warning")
                                    refresh_worker_dashboard()
                                else:
                                    ui.notify(msg, type="negative")

                            ui.button("Cancel Shift", on_click=lambda sid=shift["id"]: open_cancel_dialog(sid)).props("color=red-7 unelevated").classes("q-mt-sm")

            refresh_worker_dashboard()

        with ui.tab_panel("admin"):
            ui.label("Admin Command Center").classes("text-h5 q-mb-md")
            with ui.row().classes("w-full q-gutter-md"):
                with ui.card().classes("col-5 p-4"):
                    ui.label("Post New Shift").classes("text-subtitle1 text-bold q-mb-sm")
                    t_input = ui.input("Shift Title").classes("w-full")
                    d_input = ui.input("Description").classes("w-full")
                    l_input = ui.input("Location Type").classes("w-full")
                    p_input = ui.number("Pay Rate ($/hr)", value=25.0).classes("w-full")
                    start_input = ui.input("Start Time (YYYY-MM-DD HH:MM)").classes("w-full")
                    end_input = ui.input("End Time (YYYY-MM-DD HH:MM)").classes("w-full")
                    req_input = ui.input("Requirements (e.g. RN Verified)").classes("w-full")

                    def submit_new_shift():
                        if not t_input.value or not l_input.value:
                            ui.notify("Please fill out required fields.", type="negative")
                            return
                        create_shift(
                            t_input.value,
                            d_input.value,
                            l_input.value,
                            p_input.value,
                            start_input.value,
                            end_input.value,
                            req_input.value,
                        )
                        ui.notify("Shift published successfully to marketplace!", type="positive")
                        t_input.value = ""
                        d_input.value = ""
                        l_input.value = ""
                        p_input.value = 25.0
                        start_input.value = ""
                        end_input.value = ""
                        req_input.value = ""
                        refresh_admin_sheet()

                    ui.button("Publish Shift", on_click=submit_new_shift).props("color=primary unelevated").classes("q-mt-md")

                with ui.card().classes("col-6 p-4"):
                    ui.label("Private Master Data & Worker Status Ledger").classes("text-subtitle1 text-bold q-mb-sm")
                    admin_table_container = ui.column().classes("w-full")

                    def refresh_admin_sheet():
                        admin_table_container.clear()
                        conn = get_db_connection()
                        query = """
                            SELECT shifts.id, shifts.title, shifts.status, workers.name, workers.phone, workers.license_number
                            FROM shifts
                            LEFT JOIN workers ON shifts.assigned_worker_id = workers.id
                        """
                        data = conn.execute(query).fetchall()
                        conn.close()

                        with admin_table_container:
                            for row in data:
                                status_color = "green" if row["status"] == "Assigned" else "orange"
                                with ui.card().classes("w-full p-2 q-my-xs bg-grey-2"):
                                    ui.label(f"Shift: {row['title']} | Status: {row['status']}").classes("font-bold")
                                    if row["name"]:
                                        ui.label(f"Assigned Worker: {row['name']} | Phone: {row['phone']} | License (Vault): {row['license_number']}")
                                    else:
                                        ui.label("Unassigned / Open Marketplace").classes("text-grey")

                    refresh_admin_sheet()


if __name__ in {"__main__", "__mp_main__"}:
    ui.run(port=8080, host="0.0.0.0", reload=False)
