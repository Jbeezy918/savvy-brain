from datetime import datetime, timedelta

from nicegui import ui

# Central application state & master analytics vault (3-year compliance retention)
app_state = {
    "border_color": "#3b82f6",
}

all_shifts = [
    {
        "id": 1,
        "title": "Weekend ICU Coverage",
        "location": "Skilled Nursing Facility",
        "client": "Chloe",
        "start": datetime(2026, 7, 25, 19, 0),
        "end": datetime(2026, 7, 26, 7, 0),
        "rate": 38.0,
        "hours": 12,
        "requirement": "RN Verified",
        "status": "Assigned",
        "assigned_worker": "Maya Brooks",
        "license": "RN-2048",
        "address": "123 Care Lane",
        "issue": None,
    },
    {
        "id": 2,
        "title": "Day Shift Floor Nurse",
        "location": "H Mountain Nature Retreat - Care Unit",
        "client": "H Mountain Admin",
        "start": datetime(2026, 7, 26, 7, 0),
        "end": datetime(2026, 7, 26, 19, 0),
        "rate": 42.0,
        "hours": 12,
        "requirement": "RN Verified",
        "status": "Open",
        "assigned_worker": None,
        "license": "",
        "address": "456 Wilderness Way",
        "issue": None,
    },
]

audit_logs = []


def log_audit(action, details):
    audit_logs.append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "action": action,
        "details": details,
    })


def refresh_content():
    container = globals().get("content_container")
    if callable(container):
        if hasattr(container, "refresh"):
            container.refresh()
        else:
            container()


def update_theme(e):
    app_state["border_color"] = e.value
    ui.notify("Theme accent updated!", type="positive")
    refresh_content()


def switch_tab(tab_name):
    current_tab["selected"] = tab_name
    refresh_content()


def request_job(shift_id):
    global all_shifts
    for shift in all_shifts:
        if shift["id"] == shift_id:
            shift["status"] = "Assigned"
            shift["assigned_worker"] = "Maya Brooks"
            shift["license"] = "RN-2048"
            log_audit("SHIFT_CLAIMED", f"Shift {shift['id']} claimed by Maya Brooks.")
    ui.notify("Job requested successfully!", type="positive")
    refresh_content()


def cancel_shift(shift_id):
    global all_shifts
    for shift in all_shifts:
        if shift["id"] == shift_id:
            shift["status"] = "Cancelled"
            shift["issue"] = "Cancelled by worker"
            log_audit("SHIFT_CANCELLED", f"Shift {shift['id']} marked as cancelled/issue.")
    ui.notify("Shift cancelled.", type="warning")
    refresh_content()


def post_new_shift(title, location, rate_val, req, client_name):
    global all_shifts
    try:
        r_float = float(rate_val)
    except (TypeError, ValueError):
        r_float = 40.0

    new_id = len(all_shifts) + 1
    new_shift = {
        "id": new_id,
        "title": title or f"New Shift {new_id}",
        "location": location or "Unspecified",
        "client": client_name,
        "start": datetime.now() + timedelta(days=1),
        "end": datetime.now() + timedelta(days=1, hours=12),
        "rate": r_float,
        "hours": 12,
        "requirement": req or "Open",
        "status": "Open",
        "assigned_worker": None,
        "license": "",
        "address": location or "Unspecified",
        "issue": None,
    }
    all_shifts.append(new_shift)
    log_audit("SHIFT_POSTED", f"New shift {new_id} posted by {client_name}.")
    ui.notify("Shift successfully published!", type="positive")
    refresh_content()


current_tab = {"selected": "Marketplace"}


@ui.refreshable
def render_active_view():
    tab = current_tab["selected"]

    with ui.column().classes("w-full max-w-6xl mx-auto p-6 gap-6"):
        if tab == "Marketplace":
            ui.label("Available Marketplace Shifts (Rolling 7 Days)").classes("text-xl font-semibold text-gray-800")
            open_shifts = [s for s in all_shifts if s["status"] == "Open"]

            if not open_shifts:
                with ui.card().classes("w-full p-8 text-center bg-gray-50"):
                    ui.label("No open shifts currently available on the marketplace.").classes("text-gray-500 text-lg")
                    ui.button("Refresh Marketplace", icon="refresh", on_click=refresh_content).classes("mt-4")
            else:
                for shift in open_shifts:
                    with ui.card().classes("w-full p-4 border-l-8 shadow-sm bg-white").style(f"border-left-color: {app_state['border_color']};"):
                        with ui.row().classes("w-full justify-between items-start"):
                            ui.label(shift["title"]).classes("text-lg font-bold text-blue-600")
                            ui.badge(f"${shift['rate']}/hr", color="green").classes("text-sm")
                        ui.label(f"Facility / Location: {shift['location']}").classes("text-gray-600 text-sm")
                        ui.label(f"Client / Source: {shift['client']}").classes("text-gray-500 text-xs")
                        ui.label(f"Duration: {shift['start'].strftime('%Y-%m-%d %H:%M')} to {shift['end'].strftime('%Y-%m-%d %H:%M')}").classes("text-gray-600 text-sm")

                        with ui.row().classes("justify-end w-full mt-4"):
                            ui.button("Request Job", color="primary", on_click=lambda s_id=shift["id"]: request_job(s_id)).classes("px-6")

        elif tab == "Worker Portal":
            ui.label("Your Active Shift Commitments").classes("text-xl font-semibold text-gray-800")
            assigned_shifts = [s for s in all_shifts if s["status"] == "Assigned" and s["assigned_worker"] == "Maya Brooks"]

            if not assigned_shifts:
                with ui.card().classes("w-full p-8 text-center bg-gray-50"):
                    ui.label("You have no active shift commitments right now.").classes("text-gray-500 text-lg")
            else:
                for shift in assigned_shifts:
                    with ui.card().classes("w-full p-4 shadow-sm bg-blue-500 text-white").style(f"border-left: 8px solid {app_state['border_color']};"):
                        ui.label(shift["title"]).classes("text-lg font-bold")
                        ui.label(f"Facility: {shift['location']}").classes("text-sm")
                        ui.label(f"Time: {shift['start'].strftime('%Y-%m-%d %H:%M')} - {shift['end'].strftime('%Y-%m-%d %H:%M')}").classes("text-sm")

                        with ui.row().classes("justify-end w-full mt-4"):
                            ui.button("Cancel / Report Issue", color="red", on_click=lambda s_id=shift["id"]: cancel_shift(s_id)).classes("px-6")

        elif tab == "Client Portal":
            ui.label("Client Intake Portal (Facility Manager)").classes("text-xl font-bold text-gray-800")
            ui.label("Post new shift requests for your facility and view fulfillment status.").classes("text-gray-600 text-sm")

            with ui.row().classes("w-full gap-6"):
                with ui.card().classes("w-full md:w-1/2 p-4 bg-white shadow"):
                    ui.label("Publish New Shift").classes("text-lg font-semibold mb-2")
                    title_input = ui.input("Shift Title").classes("w-full")
                    location_input = ui.input("Facility / Address").classes("w-full")
                    rate_input = ui.input("Pay Rate ($/hr)").classes("w-full")
                    req_input = ui.input("Requirements").classes("w-full")
                    ui.button(
                        "Submit to Marketplace",
                        color="green",
                        on_click=lambda: post_new_shift(title_input.value, location_input.value, rate_input.value, req_input.value, "Chloe (Facility)"),
                    ).classes("mt-4")

                with ui.card().classes("w-full md:w-1/2 p-4 bg-gray-50 shadow"):
                    ui.label("Your Facility Shifts").classes("text-lg font-semibold mb-2")
                    for shift in all_shifts:
                        with ui.card().classes("w-full p-3 bg-white mb-2 shadow-sm"):
                            ui.label(f"{shift['title']} — Status: {shift['status']}").classes("font-bold text-sm")
                            ui.label(f"Assigned Worker: {shift['assigned_worker'] or 'Unassigned'}").classes("text-xs text-gray-600")

        elif tab == "Admin Command Center":
            ui.label("Facility Admin Command Center").classes("text-xl font-bold text-gray-800")
            ui.label("Manage facility-level shift postings and operational approvals.").classes("text-gray-600 text-sm")

            with ui.card().classes("w-full p-4 bg-white shadow mb-4"):
                ui.label("Quick Shift Posting").classes("text-lg font-semibold mb-2")
                title_input = ui.input("Shift Title").classes("w-full")
                location_input = ui.input("Location / Address").classes("w-full")
                rate_input = ui.input("Pay Rate ($/hr)").classes("w-full")
                req_input = ui.input("Requirements").classes("w-full")
                ui.button(
                    "Post Shift as Admin",
                    color="primary",
                    on_click=lambda: post_new_shift(title_input.value, location_input.value, rate_input.value, req_input.value, "Admin Portal"),
                ).classes("mt-2")

            ui.label("All Facility Shifts Ledger").classes("text-lg font-semibold mt-2")
            for shift in all_shifts:
                with ui.card().classes("w-full p-3 bg-gray-50 mb-2 shadow-sm"):
                    ui.label(f"#{shift['id']} | {shift['title']} @ {shift['location']}").classes("font-bold text-sm")
                    ui.label(f"Client: {shift['client']} | Status: {shift['status']} | Worker: {shift['assigned_worker'] or 'None'}").classes("text-xs text-gray-600")

        elif tab == "Master Owner Vault":
            ui.label("Master Owner Vault & Deep Analytics (Joe's Back-Channel)").classes("text-xl font-bold text-red-600")
            ui.label("Complete financial rollups, rolling gig counts, cancellation audits, and granular filtering.").classes("text-gray-600 text-sm mb-4")

            total_earned_pool = sum(s["rate"] * s["hours"] for s in all_shifts if s["status"] == "Assigned")
            total_gigs = len([s for s in all_shifts if s["status"] == "Assigned"])
            total_cancelled = len([s for s in all_shifts if s["status"] == "Cancelled"])
            total_issues = len([s for s in all_shifts if s["issue"] is not None])

            with ui.row().classes("w-full gap-4"):
                with ui.card().classes("p-4 bg-gray-900 text-white flex-1"):
                    ui.label("Total Revenue / Payout Pool").classes("text-xs text-gray-400")
                    ui.label(f"${total_earned_pool:,.2f}").classes("text-2xl font-bold text-green-400")
                with ui.card().classes("p-4 bg-gray-900 text-white flex-1"):
                    ui.label("Completed / Active Gigs").classes("text-xs text-gray-400")
                    ui.label(str(total_gigs)).classes("text-2xl font-bold text-blue-400")
                with ui.card().classes("p-4 bg-gray-900 text-white flex-1"):
                    ui.label("Cancellations / Issues").classes("text-xs text-gray-400")
                    ui.label(str(total_cancelled + total_issues)).classes("text-2xl font-bold text-red-400")

            ui.separator().classes("my-4")
            ui.label("Granular Audit & User Filter Controls").classes("text-lg font-semibold text-gray-800")

            with ui.row().classes("w-full gap-4 items-center"):
                filter_name = ui.input("Filter by Worker Name").classes("flex-1 bg-white")
                filter_license = ui.input("Filter by License #").classes("flex-1 bg-white")
                filter_addr = ui.input("Filter by Address/Location").classes("flex-1 bg-white")

                def reset_filters():
                    filter_name.set_value("")
                    filter_license.set_value("")
                    filter_addr.set_value("")
                    render_filtered_ledger.refresh()

                ui.button("Reset Filters", color="grey-7", on_click=reset_filters).classes("mt-4")

            @ui.refreshable
            def render_filtered_ledger():
                f_name = filter_name.value.lower()
                f_lic = filter_license.value.lower()
                f_addr = filter_addr.value.lower()

                filtered = []
                for s in all_shifts:
                    match_n = not f_name or f_name in (s["assigned_worker"] or "").lower()
                    match_l = not f_lic or f_lic in (s["license"] or "").lower()
                    match_a = not f_addr or f_addr in (s["address"] or "").lower()
                    if match_n and match_l and match_a:
                        filtered.append(s)

                ui.label(f"Matching Records ({len(filtered)})").classes("font-semibold text-gray-700 mt-4")
                if not filtered:
                    ui.label("No matching records found in the compliance database.").classes("text-sm text-gray-500 italic")
                else:
                    for s in filtered:
                        with ui.card().classes("w-full p-3 bg-white mb-2 shadow-sm border-l-4 border-blue-500"):
                            ui.label(f"Shift #{s['id']} | {s['title']} ({s['location']})").classes("font-bold text-sm")
                            ui.label(f"Worker: {s['assigned_worker'] or 'Unassigned'} | License: {s['license'] or 'N/A'} | Status: {s['status']}").classes("text-xs text-gray-600")
                            ui.label(f"Client Source: {s['client']} | Financial Value: ${s['rate'] * s['hours']:,.2f}").classes("text-xs text-green-700 font-semibold")

            render_filtered_ledger()


@ui.page("/")
def main_page():
    with ui.header().classes("bg-gray-900 text-white justify-between items-center px-6 py-3"):
        ui.label("SavvyShift | Secure Marketplace & Scheduling").classes("text-lg font-bold")

        with ui.row().classes("items-center gap-4"):
            ui.select(
                options={"#3b82f6": "Classic Blue", "#10b981": "Emerald", "#8b5cf6": "Purple", "#f59e0b": "Amber"},
                value="#3b82f6",
                label="Theme Accent",
                on_change=update_theme,
            ).classes("w-32 bg-gray-800 text-white")

    with ui.row().classes("w-full bg-gray-800 px-6 py-2 gap-4"):
        for tab_name in ["Marketplace", "Worker Portal", "Client Portal", "Admin Command Center", "Master Owner Vault"]:
            ui.button(tab_name, on_click=lambda t=tab_name: switch_tab(t)).classes("bg-gray-700 text-white hover:bg-gray-600")

    global content_container
    content_container = render_active_view
    content_container()


if __name__ in {"__main__", "__mp_main__"}:
    ui.run(port=8080, host="0.0.0.0", reload=False)
