import sys
import sqlite3
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QTabWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
)


def init_db():
    conn = sqlite3.connect("savvy_shift.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS facilities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            color_hex TEXT NOT NULL
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT,
            address TEXT,
            phone TEXT,
            date TEXT,
            time TEXT,
            days TEXT,
            hours TEXT,
            pay TEXT,
            role TEXT,
            status TEXT,
            claimant TEXT,
            facility_id INTEGER
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT,
            address TEXT,
            phone TEXT
        )
        """
    )

    conn.commit()
    conn.close()


class SavvyShiftApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SavvyShift - Real-Time Dispatch & Worker Verification")
        self.resize(1200, 800)

        init_db()

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.init_calendar_tab()
        self.init_worker_profile_tab()
        self.init_facility_tab()
        self.init_master_admin_tab()

    def init_calendar_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Calendar & Job Search: Live shift board and availability view."))
        widget.setLayout(layout)
        self.tabs.addTab(widget, "Calendar")

    def init_worker_profile_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Worker Profile: Personal data, license upload, and credential verification."))
        widget.setLayout(layout)
        self.tabs.addTab(widget, "Worker Profile")

    def init_facility_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Facility Portal: Shift intake and facility-specific management."))
        widget.setLayout(layout)
        self.tabs.addTab(widget, "Facility (Chloe / H Mountain)")

    def init_master_admin_tab(self):
        widget = QWidget()
        main_layout = QVBoxLayout()

        form_layout = QVBoxLayout()

        row1 = QHBoxLayout()
        self.client_name_input = QLineEdit()
        self.client_name_input.setPlaceholderText("Client Name")
        self.address_input = QLineEdit()
        self.address_input.setPlaceholderText("Address")
        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("Phone Number")
        row1.addWidget(self.client_name_input)
        row1.addWidget(self.address_input)
        row1.addWidget(self.phone_input)

        row2 = QHBoxLayout()
        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText("Date (YYYY-MM-DD)")
        self.time_input = QLineEdit()
        self.time_input.setPlaceholderText("Time (e.g., 07:00 - 15:00)")
        self.days_input = QLineEdit()
        self.days_input.setPlaceholderText("Days (e.g., 3)")
        self.total_hours_input = QLineEdit()
        self.total_hours_input.setPlaceholderText("Total Hours")
        row2.addWidget(self.date_input)
        row2.addWidget(self.time_input)
        row2.addWidget(self.days_input)
        row2.addWidget(self.total_hours_input)

        row3 = QHBoxLayout()
        self.pay_input = QLineEdit()
        self.pay_input.setPlaceholderText("Pay ($/hr or Total)")
        self.role_input = QLineEdit()
        self.role_input.setPlaceholderText("Role (CNA/LPN/RN)")
        row3.addWidget(self.pay_input)
        row3.addWidget(self.role_input)

        form_layout.addLayout(row1)
        form_layout.addLayout(row2)
        form_layout.addLayout(row3)

        btn_layout = QHBoxLayout()
        self.save_btn = QPushButton("Post Shift Save Customer")
        self.load_btn = QPushButton("Load Saved Customer")
        self.claim_btn = QPushButton("Claim Selected Shift")

        self.save_btn.setStyleSheet("background-color: green; color: white; font-weight: bold;")
        self.claim_btn.setStyleSheet("background-color: blue; color: white; font-weight: bold;")

        self.save_btn.clicked.connect(self.post_shift)
        self.load_btn.clicked.connect(self.load_customer)
        self.claim_btn.clicked.connect(self.claim_selected_shift)

        btn_layout.addWidget(self.save_btn)
        btn_layout.addWidget(self.load_btn)
        btn_layout.addWidget(self.claim_btn)

        self.table = QTableWidget()
        self.table.setColumnCount(11)
        self.table.setHorizontalHeaderLabels([
            "ID", "Client Name", "Address", "Phone", "Date", "Time", "Days", "Hours", "Pay", "Role", "Status"
        ])
        self.table.horizontalHeader().setStretchLastSection(True)

        main_layout.addLayout(form_layout)
        main_layout.addLayout(btn_layout)
        main_layout.addWidget(self.table)

        widget.setLayout(main_layout)
        self.tabs.addTab(widget, "Master Admin")
        self.load_shifts()

    def post_shift(self):
        client = self.client_name_input.text().strip()
        address = self.address_input.text().strip()
        phone = self.phone_input.text().strip()
        date = self.date_input.text().strip()
        time = self.time_input.text().strip()
        days = self.days_input.text().strip()
        hours = self.total_hours_input.text().strip()
        pay = self.pay_input.text().strip()
        role = self.role_input.text().strip()

        if not client or not date:
            QMessageBox.warning(self, "Validation Error", "Client Name and Date are required.")
            return

        conn = sqlite3.connect("savvy_shift.db")
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO shifts (client_name, address, phone, date, time, days, hours, pay, role, status, claimant)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', '')
            """,
            (client, address, phone, date, time, days, hours, pay, role),
        )
        cursor.execute("SELECT id FROM customers WHERE client_name = ?", (client,))
        if not cursor.fetchone():
            cursor.execute(
                """
                INSERT INTO customers (client_name, address, phone)
                VALUES (?, ?, ?)
                """,
                (client, address, phone),
            )
        conn.commit()
        conn.close()

        QMessageBox.information(self, "Success", "Shift posted successfully.")
        self.load_shifts()

    def load_customer(self):
        name = self.client_name_input.text().strip()
        if not name:
            return
        conn = sqlite3.connect("savvy_shift.db")
        cursor = conn.cursor()
        cursor.execute(
            "SELECT client_name, address, phone FROM customers WHERE client_name LIKE ?",
            (f"%{name}%",),
        )
        customer = cursor.fetchone()
        conn.close()

        if customer:
            self.client_name_input.setText(customer[0] or "")
            self.address_input.setText(customer[1] or "")
            self.phone_input.setText(customer[2] or "")
            QMessageBox.information(self, "Loaded", f"Loaded profile for {customer[0]}")
        else:
            QMessageBox.warning(self, "Not Found", "No saved customer profile matched your search.")

    def claim_selected_shift(self):
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            QMessageBox.warning(self, "Selection Error", "Please select a shift from the table first.")
            return

        shift_id = self.table.item(selected[0].row(), 0).text()
        conn = sqlite3.connect("savvy_shift.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE shifts SET status = ?, claimant = ? WHERE id = ?", ("Fulfilled", "Claimed", shift_id))
        conn.commit()
        conn.close()
        self.load_shifts()

    def load_shifts(self):
        conn = sqlite3.connect("savvy_shift.db")
        cursor = conn.cursor()
        cursor.execute("SELECT id, client_name, address, phone, date, time, days, hours, pay, role, status FROM shifts")
        rows = cursor.fetchall()
        conn.close()

        self.table.setRowCount(len(rows))
        for row_idx, row in enumerate(rows):
            for col_idx, value in enumerate(row):
                item = QTableWidgetItem(str(value or ""))
                self.table.setItem(row_idx, col_idx, item)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SavvyShiftApp()
    window.show()
    sys.exit(app.exec_())
