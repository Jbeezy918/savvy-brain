from __future__ import annotations
from typing import Any
import requests

class HomeAssistantClient:
    def __init__(self, base_url: str, token: str, timeout: int = 20):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        response = self.session.request(
            method,
            f"{self.base_url}{path}",
            timeout=self.timeout,
            **kwargs,
        )
        response.raise_for_status()
        if not response.content:
            return None
        return response.json()

    def api_status(self) -> dict[str, Any]:
        return self._request("GET", "/api/")

    def config(self) -> dict[str, Any]:
        return self._request("GET", "/api/config")

    def states(self) -> list[dict[str, Any]]:
        return self._request("GET", "/api/states")

    def services(self) -> list[dict[str, Any]]:
        return self._request("GET", "/api/services")

    def call_service(self, domain: str, service: str, data: dict[str, Any]) -> Any:
        return self._request("POST", f"/api/services/{domain}/{service}", json=data)
