import requests

class OllamaClient:
    def __init__(self, base_url: str, timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def health(self) -> dict:
        response = requests.get(f"{self.base_url}/api/tags", timeout=15)
        response.raise_for_status()
        return response.json()

    def generate(self, model: str, prompt: str) -> str:
        response = requests.post(
            f"{self.base_url}/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json().get("response", "").strip()
