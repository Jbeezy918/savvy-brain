from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    ha_url: str = os.getenv("HA_URL", "http://192.168.68.110:8123").rstrip("/")
    ha_token: str = os.getenv("HA_TOKEN", "")
    ollama_url: str = os.getenv("OLLAMA_URL", "http://192.168.68.100:11434").rstrip("/")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
    builder_model: str = os.getenv("BUILDER_MODEL", "qwen2.5-coder:32b")
    dry_run: bool = os.getenv("DRY_RUN", "true").lower() == "true"

    def validate(self) -> None:
        if not self.ha_token or "PASTE_" in self.ha_token:
            raise ValueError("HA_TOKEN is missing. Add a Home Assistant long-lived access token to .env.")
