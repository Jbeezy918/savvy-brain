# Savvy HA Agents v1

Three-agent local Home Assistant control system:

- **Savvy Hub** — receives requests and routes work.
- **Builder** — creates and validates Home Assistant actions/configuration.
- **Guardian** — monitors health and performs approved low-risk recovery.

## Safety improvements

This version does not edit Home Assistant `.storage`, does not assume root SSH,
does not delete integrations, and does not report success without checking results.
It uses Home Assistant's authenticated REST API.

## Requirements

1. Home Assistant at `http://192.168.68.110:8123`
2. A Home Assistant long-lived access token
3. Ollama reachable from the machine running these agents
4. Existing Assist pipeline:
   - Conversation: Ollama Conversation
   - STT: faster-whisper
   - TTS: Piper
5. For room wake words, use Home Assistant Assist satellites with openWakeWord.

## Installation

```bash
cd ~/Desktop
unzip Savvy_HA_Agents_v1.zip
cd Savvy_HA_Agents_v1
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env`, add the HA token, and set the correct Ollama host.

Run:

```bash
source .venv/bin/activate
python3 health_check.py
python3 run_agents.py
```
