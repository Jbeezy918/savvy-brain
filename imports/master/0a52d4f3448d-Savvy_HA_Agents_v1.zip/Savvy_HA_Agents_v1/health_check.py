import json
from savvy_ha.config import Settings
from savvy_ha.ha_client import HomeAssistantClient
from savvy_ha.ollama_client import OllamaClient

def main():
    settings = Settings()
    settings.validate()

    ha = HomeAssistantClient(settings.ha_url, settings.ha_token)
    ollama = OllamaClient(settings.ollama_url)

    result = {
        "home_assistant": ha.api_status(),
        "home_assistant_config": ha.config(),
        "ollama_models": ollama.health(),
        "dry_run": settings.dry_run,
    }
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
