# Home Assistant voice and wake-word setup

Verified prior pipeline:
- Conversation agent: Ollama Conversation
- Speech-to-text: faster-whisper
- Text-to-speech: Piper
- Voice previously used: ljspeech medium; arctic medium also appeared earlier

## Required design

1. Home Assistant remains the voice-pipeline authority.
2. An Assist satellite handles microphone, wake word and speaker.
3. openWakeWord detects the wake phrase locally.
4. faster-whisper transcribes.
5. Ollama Conversation interprets the request.
6. Piper speaks the response through the satellite speaker.
7. Savvy Hub, Builder and Guardian handle advanced work.

## Echo limitation

Amazon Echo devices are not general-purpose local Assist satellites. Alexa Media
Player can provide media-player and announcement services, but it does not convert
Echo microphones into unrestricted local openWakeWord satellites.

Use a supported Assist satellite for always-listening wake-word control, and use
Home Assistant media-player entities for announcements to other speakers.
