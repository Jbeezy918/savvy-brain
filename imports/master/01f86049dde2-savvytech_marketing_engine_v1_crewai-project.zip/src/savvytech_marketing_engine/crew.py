import os


from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	ExaSearchTool,
	ScrapeWebsiteTool
)






@CrewBase
class SavvytechMarketingEngineCrew:
    """SavvytechMarketingEngine crew"""

    
    @agent
    def seo_market_research_specialist(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["seo_market_research_specialist"],
            
            
            tools=[				ExaSearchTool(),
				ScrapeWebsiteTool()],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def marketing_strategy_director(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["marketing_strategy_director"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def direct_response_copywriter(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["direct_response_copywriter"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def brand_content_quality_auditor(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["brand_content_quality_auditor"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    

    
    @task
    def research_tech_automation_trends(self) -> Task:
        return Task(
            config=self.tasks_config["research_tech_automation_trends"],
            markdown=False,
            
            
        )
    
    @task
    def develop_campaign_strategy(self) -> Task:
        return Task(
            config=self.tasks_config["develop_campaign_strategy"],
            markdown=False,
            
            
        )
    
    @task
    def write_ad_copy_email_sequences(self) -> Task:
        return Task(
            config=self.tasks_config["write_ad_copy_email_sequences"],
            markdown=False,
            
            
        )
    
    @task
    def brand_quality_audit(self) -> Task:
        return Task(
            config=self.tasks_config["brand_quality_audit"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the SavvytechMarketingEngine crew"""

        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,

            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


